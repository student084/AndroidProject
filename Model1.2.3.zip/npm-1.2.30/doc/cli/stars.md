npm-stars(1) -- View packages marked as favorites
=================================================

## SYNOPSIS

    npm stars
    npm stars [username]

## DESCRIPTION

If you have starred a lot of neat things and want to find them again
quickly this command lets you do just that.

You may also want to see your friend's favorite packages, in this case
you will most certainly enjoy this command.

## SEE ALSO

* npm-star(1)
* npm-view(1)
* npm-whoami(1)
* npm-adduser(1)
