npm-whoami(1) -- Display npm username
=====================================

## SYNOPSIS

    npm whoami

## DESCRIPTION

Print the `username` config to standard output.

## SEE ALSO

* npm-config(1)
* npm-adduser(1)
